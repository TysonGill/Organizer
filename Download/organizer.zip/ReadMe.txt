Here is your Organizer application.

We don't include documentation with the distribution. 
Rather, it is available on our support forum where you can always find current info:

http://surgicalgrade.net/forums/


To run Organizer, just unzip it to any folder and execute organizer.exe.
You can create a Windows shortcut to this and place it on your desktop or task bar.

BE SURE TO UNZIP THIS FOLDER BEFORE ATTEMPTING TO RUN ANYTHING.
IF UPGRADING, BE SURE TO BACKUP YOUR OLD ORGANIZER.DAT FILE SO IT DOES NOT GET OVERWRITTEN.

If you would like to support this project, you can do so through our donation page:

http://surgicalgrade.net/organizer/support/



Enjoy using Organizer!
